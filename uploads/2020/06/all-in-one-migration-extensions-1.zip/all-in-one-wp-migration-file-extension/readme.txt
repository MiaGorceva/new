Install instructions: https://help.servmask.com/knowledgebase/install-instructions-for-file-extension/
User guide: https://help.servmask.com/knowledgebase/file-extension-user-guide/
